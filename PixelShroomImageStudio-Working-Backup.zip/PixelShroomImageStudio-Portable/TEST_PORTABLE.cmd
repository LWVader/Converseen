@echo off
setlocal
cd /d "%~dp0"
set "PATH=%SystemRoot%\System32;%SystemRoot%"
echo Testing packaged Image Studio using a clean Windows PATH...
"%~dp0PixelShroomImageStudio.exe" --supported-formats > "%TEMP%\pixelshroom-formats.txt" 2> "%TEMP%\pixelshroom-errors.txt"
echo Exit code: %ERRORLEVEL%
findstr /I "JPEG PNG WEBP" "%TEMP%\pixelshroom-formats.txt"
echo Error log: %TEMP%\pixelshroom-errors.txt
echo Then double-click PixelShroomImageStudio.exe and test actual conversions.
pause
